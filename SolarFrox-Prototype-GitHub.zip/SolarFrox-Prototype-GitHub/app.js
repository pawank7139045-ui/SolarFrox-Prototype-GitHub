const pages = [...document.querySelectorAll(".page")];
const navButtons = [...document.querySelectorAll("[data-page]")];
const title = document.getElementById("pageTitle");
const titles = {dashboard:"Good afternoon, Farmer 👋",history:"History & Analytics",alerts:"Alerts & Notifications",settings:"Storage Settings"};

function go(page){
  pages.forEach(p=>p.classList.toggle("active",p.id===page));
  navButtons.forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  if(titles[page]) title.textContent=titles[page];
  window.scrollTo({top:0,behavior:"smooth"});
}
navButtons.forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
document.querySelectorAll("[data-page-jump]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.pageJump)));

const toast = document.getElementById("toast");
function showToast(msg){toast.textContent=msg;toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),2600)}

document.getElementById("themeBtn").onclick=()=>{document.body.classList.toggle("dark");showToast(document.body.classList.contains("dark")?"Dark mode enabled":"Light mode enabled")};

let systemOn=true;
const fan=document.getElementById("fanRing"), power=document.getElementById("powerBtn"), state=document.getElementById("coolState");
fan.classList.add("running");
power.onclick=()=>{
  systemOn=!systemOn;
  fan.classList.toggle("running",systemOn);
  state.textContent=systemOn?"SYSTEM ON":"SYSTEM OFF";
  power.innerHTML=systemOn?'<span>⏻</span> Turn system OFF':'<span>⏻</span> Turn system ON';
  showToast(systemOn?"Cooling system turned ON":"Cooling system turned OFF");
};

document.getElementById("saveSettings").onclick=()=>showToast("Settings saved successfully");
document.getElementById("readAll").onclick=()=>{document.getElementById("alertCount").textContent="0";showToast("All alerts marked as read")};
document.getElementById("exportBtn").onclick=()=>{
 const rows=[["Time","Temperature","Humidity","Battery"],["00:00","4.1","80","78"],["06:00","4.0","81","77"],["12:00","4.4","84","76"],["18:00","4.7","82","75"],["24:00","4.2","82","76"]];
 const csv=rows.map(r=>r.join(",")).join("\n"); const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="solarfrox-history.csv";a.click();showToast("CSV export downloaded");
};
document.getElementById("logoutBtn").onclick=()=>showToast("Prototype mode: logout disabled");

function line(points,color,width=3){
  const d=points.map((p,i)=>(i?"L":"M")+p[0]+" "+p[1]).join(" ");
  return `<path d="${d}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round"/>`;
}
function chart(svgId,large=false){
 const svg=document.getElementById(svgId); if(!svg)return;
 const w=large?920:760,h=large?330:260;
 let grid="";
 for(let i=1;i<6;i++){const y=(h/6)*i;grid+=`<line x1="0" y1="${y}" x2="${w}" y2="${y}" stroke="#e8efeb" stroke-width="1"/>`}
 for(let i=1;i<8;i++){const x=(w/8)*i;grid+=`<line x1="${x}" y1="0" x2="${x}" y2="${h}" stroke="#f0f4f1" stroke-width="1"/>`}
 const mk=(arr,base,amp)=>arr.map((v,i)=>[i*(w/(arr.length-1)),base-v*amp]);
 const temp=mk([4,4.1,4.0,4.2,4.6,4.5,4.7,4.4,4.2,4.1,4.3,4.2],h*.43,11);
 const hum=mk([7,6.4,7.5,8.2,7.4,6.9,8.5,8.9,7.6,7.0,6.2,6.7],h*.72,9);
 const bat=mk([8,8,7.9,7.8,7.7,7.2,6.4,5.7,5.2,4.8,4.2,4],h*.94,11);
 svg.innerHTML=grid+line(temp,"#2776a5")+line(hum,"#298052")+line(bat,"#c69022",large?4:3);
 [temp,hum,bat].forEach((series,idx)=>series.forEach((p,i)=>{if(i%2===0){svg.innerHTML+=`<circle cx="${p[0]}" cy="${p[1]}" r="${large?3:2.3}" fill="${["#2776a5","#298052","#c69022"][idx]}"/>`}}));
}
chart("mainChart");chart("historyChart",true);

setInterval(()=>{
 if(!systemOn)return;
 const t=(4+Math.random()*0.7).toFixed(1), h=Math.round(80+Math.random()*5), b=Math.max(55,76-Math.floor(Math.random()*3)), s=Math.round(300+Math.random()*60);
 document.getElementById("tempValue").textContent=t;
 document.getElementById("humidityValue").textContent=h;
 document.getElementById("batteryValue").textContent=b;
 document.getElementById("solarValue").textContent=s;
},5000);
